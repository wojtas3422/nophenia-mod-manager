extends Node

var player_name: String = ""
var auto_connect := false
var address := "wss://super-cirno.duckdns.org:42424"
var start_server := false
var server_port := 42424
var rng_seed := 1337
var collision := true
# var items_unlocked: Array
var items_visible: Dictionary
